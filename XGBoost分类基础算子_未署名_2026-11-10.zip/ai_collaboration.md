# 实际 AI 协作记录

本项目由 Codex 在本次会话中根据用户附件实现、运行和修正。没有虚构人工复审、额外用户轮次或多代理协作。
以下三条关键提示词是**同一份用户请求中的原文片段**，不是三次独立对话；题库要求“至少3条关键提示词”，
此处按三项实际指令记录。完整提示词来源为用户附加的 `Pasted text.txt`，原题库为权威规格。

## 1. 规格与实现范围

**实际提示词**：“Read the examination file first and treat it as the authoritative requirements specification.”

**意图**：以题目一为范围，复用已有环境，不修改原文件。

**AI 执行摘要**：先读取题库和环境清单，确认 `.venv` 只有 pip/setuptools；安装 CPU XGBoost、
Dask Distributed、sklearn 及绘图测试依赖。实现统一封装和独立启动脚本。

**验证方式**：检查原题要求与源文件、运行 pip check 和自动化测试。未声称有人类审阅。

## 2. 防泄漏与持久化

**实际提示词**：“Perform feature reduction only after splitting to prevent data leakage. Fit the reducer on training data and apply the same transformation to validation and future prediction data.”

**意图**：防止把验证数据统计信息用于预处理；保证保存后仍可预测。

**AI 执行摘要**：将 feature_reduction 定义为配置操作，在 train 切分之后才 fit；
保存标签编码器、列元数据和降维器。Dask 模型提取为普通本地估计器，关闭集群后验证 reload。

**验证方式**：测试 reducer 的方差/均值与训练索引对应样本的统计值一致，验证 PCA 两种参数语义、
原始输入预测、列顺序错误，以及方差筛选/PCA/Dask 保存加载后的概率完全不变。

## 3. 真实分布式与对比

**实际提示词**：“Do not assume the two trained models must be numerically identical. Distributed histogram construction may produce different split thresholds. Report actual differences transparently rather than forcing equivalence.”

**意图**：验证真正的多 Worker 训练，避免为了满足原题一致性而篡改结果。

**AI 执行摘要**：在 XGBoost collective 训练结束回调中采集 rank/world_size/PID；
使用相同 20 万样本和切分，按总线程预算匹配资源，分别记录集群启动、数据分发、fit 耗时。

**验证方式**：自动测试和完整实验校验 rank 集合、不同进程和 world_size；
保存双方验证概率与索引，用真实标签一致率和概率差统计评估一致性，结果见 results/report.md。

## 实现中的实际调试

初稿参数探测仅将少量 wrapper 参数送给原生引擎，自检时发现这会漏掉 max_leaves 等值校验，
在首次测试前改用安装版本的 get_xgb_params() 提取原生参数。
首次自动测试发现两处错误：未训练 predict 先访问标签编码器，抛出了不清晰的 AttributeError；
以及禁用全局默认 Client 后，distributed.wait 仍需当前 Client 上下文。
分别添加显式拟合检查和局部 client.as_current() 上下文，保留首次日志 tests_initial.log 并重跑验证。
后续补充 early_stopping_rounds 和 importance_type 的错误校验，最终 23 项测试通过。
另用 start_cluster.py 启动外部进程集群，验证训练后集群仍存活、模型加载预测不变，以及 Ctrl-C 退出码为 0。
在补充参数校验和重置 Worker 参与证据之后，重新执行 20 万样本实验；两次标签一致率和概率差统计相同，
报告保留最终执行的实际耗时。另在全新 Python 进程中加载双方模型，核对保存的全部 40,000 个验证概率。
最终自动测试和实验日志保存在 results/，实际修正以这些日志和源代码为准。
所有结论来自本次工具运行和官方文档参考，未编造用户反馈或人工优化记录。
